from src.config import THEME_COLORS

def toggle_theme(root, theme_state, theme_button, widgets):
    """Toggle between light and dark themes"""
    new_theme = "light" if theme_state["current"] == "dark" else "dark"
    theme_state["current"] = new_theme
    colors = THEME_COLORS[new_theme]
    
    # Update entry widgets
    for entry in widgets["entry"]:
        current_text = entry.get()
        placeholders = [
            "Enter phone numbers",
            "Enter your custom message",
            "Select a CSV file",
            "Enter default message for CSV"
        ]
        if current_text in placeholders:
            entry.config(fg=colors["secondary"])
    
    # Update theme button
    theme_button.config(
        text="🌙 Dark Mode" if new_theme == "light" else "☀️ Light Mode",
        bg=colors["button_bg"],
        fg=colors["button_fg"],
        activebackground=colors["button_active_bg"]
    )
    
    # Update main window
    root.configure(bg=colors["bg"])
    
    # Update all tracked widgets
    for widget_type, widget_list in widgets.items():
        if widget_type == "label":
            for label in widget_list:
                label.config(bg=colors["bg"], fg=colors["fg"])
        elif widget_type == "frame":
            for frame in widget_list:
                frame.config(bg=colors["bg"])
        elif widget_type == "entry":
            for entry in widget_list:
                entry.config(bg=colors["entry_bg"], insertbackground=colors["fg"])
        elif widget_type == "button":
            for button in widget_list:
                button.config(bg=colors["button_bg"], fg=colors["button_fg"], 
                             activebackground=colors["button_active_bg"], activeforeground=colors["button_fg"])
        elif widget_type == "send_button":
            for button in widget_list:
                button.config(bg=colors["send_button_bg"], fg=colors["button_fg"], 
                             activebackground=colors["send_button_active_bg"], activeforeground=colors["button_fg"])
        elif widget_type == "reset_button":
            for button in widget_list:
                button.config(bg=colors["reset_button_bg"], fg=colors["button_fg"], 
                             activebackground=colors["reset_button_active_bg"], activeforeground=colors["button_fg"])
        elif widget_type == "log":
            for log in widget_list:
                log.config(bg=colors["log_bg"], fg=colors["log_fg"])
        elif widget_type == "progress":
            for progress in widget_list:
                progress.config(bg=colors["progress_bg"], fg=colors["progress_fg"])