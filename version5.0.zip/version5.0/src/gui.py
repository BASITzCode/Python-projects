import os
import tkinter as tk
from tkinter import filedialog, scrolledtext, messagebox, Listbox
from threading import Thread
import datetime
from tkinter import ttk
from src.config import THEME_COLORS, DEFAULT_RETRIES, SUPPORTED_ATTACHMENT_EXTENSIONS
from src.theme import toggle_theme
from src.whatsapp import send_whatsapp_message, reset_whatsapp_session
from src.csv_handler import read_contacts_from_csv

def update_progress(progress_bar, value=0, max_value=100):
    """Update the progress bar"""
    if value > max_value:
        value = max_value
    elif value < 0:
        value = 0
    progress_bar["value"] = value
    progress_bar.update()

def launch_gui():
    """Initialize and launch the Tkinter GUI"""
    root = tk.Tk()
    root.title("WhatsApp Bulk Sender - Developed by Abdul Basit")
    root.geometry("1000x680")
    
    theme_state = {"current": "dark"}
    widgets = {
        "label": [],
        "frame": [],
        "entry": [],
        "button": [],
        "send_button": [],
        "reset_button": [],
        "log": [],
        "progress": [],
        "listbox": []
    }
    
    colors = THEME_COLORS["dark"]
    root.configure(bg=colors["bg"])

    style = {
        "font": ("Helvetica", 12),
        "bg": colors["bg"],
        "fg": colors["fg"]
    }

    # Header Frame
    header_frame = tk.Frame(root, bg=colors["bg"])
    header_frame.pack(fill=tk.X, pady=10)
    widgets["frame"].append(header_frame)
    
    title = tk.Label(header_frame, text="WhatsApp Bulk Sender", font=("Helvetica", 20, "bold"), 
                    fg=colors["fg"], bg=colors["bg"])
    title.pack(side=tk.LEFT, padx=20)
    widgets["label"].append(title)
    
    theme_button = tk.Button(header_frame, text="☀️ Light Mode",
                           font=("Helvetica", 10), bg=colors["button_bg"], fg=colors["button_fg"],
                           relief="flat", activebackground=colors["button_active_bg"], 
                           activeforeground=colors["button_fg"],
                           command=lambda: toggle_theme(root, theme_state, theme_button, widgets))
    theme_button.pack(side=tk.RIGHT, padx=20)
    widgets["button"].append(theme_button)

    # Main Content Frame (2 columns)
    main_frame = tk.Frame(root, bg=colors["bg"])
    main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
    widgets["frame"].append(main_frame)
    
    # Left Column - Direct Message
    left_frame = tk.Frame(main_frame, bg=colors["bg"], bd=1, relief=tk.GROOVE, padx=10, pady=10)
    left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
    widgets["frame"].append(left_frame)
    
    # Right Column - CSV Upload
    right_frame = tk.Frame(main_frame, bg=colors["bg"], bd=1, relief=tk.GROOVE, padx=10, pady=10)
    right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5)
    widgets["frame"].append(right_frame)
    
    # Helper functions
    def choose_csv_file():
        """Open file dialog to select CSV file"""
        filepath = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if filepath:
            file_entry.delete(0, tk.END)
            file_entry.insert(0, filepath)
            file_entry.config(fg=colors["fg"])

    def choose_attachment_files(listbox):
        """Open file dialog to select multiple attachment files"""
        filetypes = [("Supported Files", list(SUPPORTED_ATTACHMENT_EXTENSIONS)), ("All Files", "*.*")]
        filepaths = filedialog.askopenfilenames(filetypes=filetypes)
        if filepaths:
            listbox.delete(0, tk.END)
            for filepath in filepaths:
                listbox.insert(tk.END, filepath)
            listbox.config(fg=colors["fg"])

    def gui_log(status, content):
        """Update GUI log display"""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        color_map = {
            "success": "#4CAF50",
            "error": "#F44336", 
            "warning": "#FF9800",
            "info": "#2196F3",
            "retry": "#9C27B0",
            "summary": "#009688"
        }
        color = color_map.get(status.lower(), colors["fg"])
        
        log_output.config(state=tk.NORMAL)
        log_output.insert(tk.END, f"[{timestamp}] {status.upper()}: ", "bold")
        log_output.insert(tk.END, f"{content}\n", f"color_{status.lower()}")
        log_output.tag_config("bold", font=("Helvetica", 10, "bold"))
        log_output.tag_config(f"color_{status.lower()}", foreground=color)
        log_output.config(state=tk.DISABLED)
        log_output.see(tk.END)

    def on_focus_in(event, entry, placeholder):
        """Handle focus in event for entry fields"""
        if entry.get() == placeholder:
            entry.delete(0, tk.END)
            entry.config(fg=colors["fg"])

    def on_focus_out(event, entry, placeholder):
        """Handle focus out event for entry fields"""
        if entry.get() == "":
            entry.insert(0, placeholder)
            entry.config(fg=colors["secondary"])

    def reset_session():
        """Reset WhatsApp session and initiate new QR code scan"""
        def process_reset():
            send_button.config(state=tk.DISABLED)
            reset_button.config(state=tk.DISABLED)
            progress_bar["value"] = 0
            
            gui_log("info", "Resetting WhatsApp session...")
            update_progress(progress_bar, 30)
            
            if reset_whatsapp_session(gui_log):
                update_progress(progress_bar, 100)
                gui_log("success", "WhatsApp session reset complete. New login successful.")
            else:
                update_progress(progress_bar, 100)
                gui_log("error", "Failed to reset WhatsApp session completely.")
            
            send_button.config(state=tk.NORMAL)
            reset_button.config(state=tk.NORMAL)
            
        Thread(target=process_reset).start()

    def send_all():
        """Process and send messages to all recipients, with optional multiple attachments"""
        def process():
            send_button.config(state=tk.DISABLED)
            reset_button.config(state=tk.DISABLED)
            progress_bar["value"] = 0
            
            try:
                filepath = file_entry.get().strip()
                if filepath == "Select a CSV file":
                    filepath = ""
                    
                default_msg = default_msg_entry.get().strip()
                if default_msg == "Enter default message for CSV":
                    default_msg = ""
                    
                default_attachments = list(default_attachment_listbox.get(0, tk.END))
                if not default_attachments:
                    default_attachments = None
                    
                retries = retry_entry.get().strip()
                retry_count = int(retries) if retries.isdigit() else DEFAULT_RETRIES

                phone_numbers = custom_number_entry.get().strip()
                if phone_numbers == "Enter phone numbers":
                    phone_numbers = ""
                    
                custom_message = custom_message_entry.get().strip()
                if custom_message == "Enter your custom message":
                    custom_message = ""
                    
                custom_attachments = list(custom_attachment_listbox.get(0, tk.END))
                if not custom_attachments:
                    custom_attachments = None

                has_direct_input = phone_numbers and custom_message
                has_csv_input = filepath and filepath != ""
                
                if not has_direct_input and not has_csv_input:
                    messagebox.showwarning("Input Missing", "Enter phone numbers with a message OR select a CSV file.")
                    return

                if phone_numbers and not custom_message:
                    messagebox.showwarning("Input Missing", "Please enter a message for the direct phone numbers.")
                    return
                    
                if filepath and not os.path.exists(filepath):
                    messagebox.showwarning("Invalid File", "The selected CSV file does not exist.")
                    return

                # Validate attachments
                if custom_attachments:
                    invalid_files = []
                    invalid_types = []
                    for attachment in custom_attachments:
                        if not os.path.isfile(attachment):
                            invalid_files.append(attachment)
                        else:
                            _, ext = os.path.splitext(attachment.lower())
                            if ext not in SUPPORTED_ATTACHMENT_EXTENSIONS:
                                invalid_types.append(attachment)
                    if invalid_files:
                        messagebox.showwarning("Invalid Attachments", f"These attachment files do not exist:\n{', '.join(invalid_files)}")
                        return
                    if invalid_types:
                        messagebox.showwarning("Invalid Attachments", f"These attachment types are unsupported:\n{', '.join(invalid_types)}")
                        return
                        
                if default_attachments:
                    invalid_files = []
                    invalid_types = []
                    for attachment in default_attachments:
                        if not os.path.isfile(attachment):
                            invalid_files.append(attachment)
                        else:
                            _, ext = os.path.splitext(attachment.lower())
                            if ext not in SUPPORTED_ATTACHMENT_EXTENSIONS:
                                invalid_types.append(attachment)
                    if invalid_files:
                        messagebox.showwarning("Invalid Default Attachments", f"These default attachment files do not exist:\n{', '.join(invalid_files)}")
                        return
                    if invalid_types:
                        messagebox.showwarning("Invalid Default Attachments", f"These default attachment types are unsupported:\n{', '.join(invalid_types)}")
                        return

                total_success, total_fail = 0, 0
                update_progress(progress_bar, 10)

                direct_numbers = phone_numbers.split(",") if has_direct_input else []
                total_direct = len(direct_numbers) if direct_numbers else 0
                
                csv_contacts = []
                if has_csv_input:
                    csv_contacts = read_contacts_from_csv(filepath, default_message=default_msg, default_attachments=default_attachments)
                    
                total_items = total_direct + len(csv_contacts)
                if total_items == 0:
                    update_progress(progress_bar, 100)
                    gui_log("warning", "No valid contacts to process")
                    return
                
                progress_per_item = 80 / total_items if total_items > 0 else 0
                current_progress = 10

                if has_direct_input:
                    gui_log("info", "Processing direct phone numbers...")
                    for i, phone_number in enumerate(direct_numbers):
                        phone_number = phone_number.strip()
                        if phone_number:
                            success = send_whatsapp_message(phone_number, custom_message, custom_attachments, retry_count, gui_log)
                            if success:
                                total_success += 1
                            else:
                                total_fail += 1
                            current_progress += progress_per_item
                            update_progress(progress_bar, current_progress)

                if has_csv_input:
                    gui_log("info", f"Processing CSV file: {os.path.basename(filepath)}...")
                    gui_log("info", f"Found {len(csv_contacts)} valid contacts in CSV")
                    
                    for i, (phone, msg, attachments) in enumerate(csv_contacts):
                        if not msg:
                            gui_log("warning", f"No message for {phone} — skipped")
                            continue
                        success = send_whatsapp_message(phone, msg, attachments, retry_count, gui_log)
                        if success:
                            total_success += 1
                        else:
                            total_fail += 1
                        current_progress += progress_per_item
                        update_progress(progress_bar, current_progress)

                update_progress(progress_bar, 100)
                gui_log("summary", f"Finished sending. Success: {total_success}, Failures: {total_fail}")
            
            except Exception as e:
                gui_log("error", f"An error occurred during processing: {str(e)}")
                update_progress(progress_bar, 100)
            
            finally:
                send_button.config(state=tk.NORMAL)
                reset_button.config(state=tk.NORMAL)

        Thread(target=process).start()

    # Left Column Content - Direct Message
    left_title = tk.Label(left_frame, text="Direct Message", font=("Helvetica", 16, "bold"), 
                         fg=colors["fg"], bg=colors["bg"])
    left_title.pack(anchor=tk.W, pady=5)
    widgets["label"].append(left_title)
    
    # Phone Numbers
    custom_number_label = tk.Label(left_frame, text="Phone Numbers (comma-separated):", **style)
    custom_number_label.pack(anchor=tk.W, pady=(10, 2))
    widgets["label"].append(custom_number_label)
    
    custom_number_entry = tk.Entry(left_frame, width=50, relief="flat", fg=colors["secondary"], bg=colors["entry_bg"])
    custom_number_entry.insert(0, "Enter phone numbers")
    custom_number_entry.bind("<FocusIn>", lambda e: on_focus_in(e, custom_number_entry, "Enter phone numbers"))
    custom_number_entry.bind("<FocusOut>", lambda e: on_focus_out(e, custom_number_entry, "Enter phone numbers"))
    custom_number_entry.pack(fill=tk.X, pady=2)
    widgets["entry"].append(custom_number_entry)

    # Custom Message
    custom_message_label = tk.Label(left_frame, text="Custom Message:", **style)
    custom_message_label.pack(anchor=tk.W, pady=(10, 2))
    widgets["label"].append(custom_message_label)
    
    custom_message_entry = tk.Entry(left_frame, width=50, relief="flat", fg=colors["secondary"], bg=colors["entry_bg"])
    custom_message_entry.insert(0, "Enter your custom message")
    custom_message_entry.bind("<FocusIn>", lambda e: on_focus_in(e, custom_message_entry, "Enter your custom message"))
    custom_message_entry.bind("<FocusOut>", lambda e: on_focus_out(e, custom_message_entry, "Enter your custom message"))
    custom_message_entry.pack(fill=tk.X, pady=2)
    widgets["entry"].append(custom_message_entry)

    # Custom Attachments
    custom_attachment_label = tk.Label(left_frame, text="Attachments (optional):", **style)
    custom_attachment_label.pack(anchor=tk.W, pady=(10, 2))
    widgets["label"].append(custom_attachment_label)
    
    custom_attachment_frame = tk.Frame(left_frame, bg=colors["bg"])
    custom_attachment_frame.pack(fill=tk.X, pady=2)
    widgets["frame"].append(custom_attachment_frame)
    
    custom_attachment_listbox = Listbox(custom_attachment_frame, height=3, bg=colors["entry_bg"], fg=colors["secondary"], relief="flat")
    custom_attachment_listbox.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
    widgets["listbox"].append(custom_attachment_listbox)
    
    custom_attachment_button = tk.Button(custom_attachment_frame, text="Browse", 
                                      command=lambda: choose_attachment_files(custom_attachment_listbox),
                                      bg=colors["button_bg"], fg=colors["button_fg"], relief="flat", 
                                      activebackground=colors["button_active_bg"], activeforeground=colors["button_fg"])
    custom_attachment_button.pack(side=tk.RIGHT)
    widgets["button"].append(custom_attachment_button)

    # Retry count
    retry_frame = tk.Frame(left_frame, bg=colors["bg"])
    retry_frame.pack(fill=tk.X, pady=(10, 2))
    widgets["frame"].append(retry_frame)
    
    retry_label = tk.Label(retry_frame, text="Retries:", **style)
    retry_label.pack(side=tk.LEFT, pady=2)
    widgets["label"].append(retry_label)
    
    retry_entry = tk.Entry(retry_frame, width=5, relief="flat", bg=colors["entry_bg"], fg=colors["fg"])
    retry_entry.insert(0, str(DEFAULT_RETRIES))
    retry_entry.pack(side=tk.LEFT, padx=5)
    widgets["entry"].append(retry_entry)

    # Right Column Content - CSV Upload
    right_title = tk.Label(right_frame, text="CSV Upload", font=("Helvetica", 16, "bold"), 
                          fg=colors["fg"], bg=colors["bg"])
    right_title.pack(anchor=tk.W, pady=5)
    widgets["label"].append(right_title)
    
    # CSV File Selection
    file_frame = tk.Frame(right_frame, bg=colors["bg"])
    file_frame.pack(fill=tk.X, pady=(10, 2))
    widgets["frame"].append(file_frame)
    
    file_entry = tk.Entry(file_frame, width=45, relief="flat", fg=colors["secondary"], bg=colors["entry_bg"])
    file_entry.insert(0, "Select a CSV file")
    file_entry.bind("<FocusIn>", lambda e: on_focus_in(e, file_entry, "Select a CSV file"))
    file_entry.bind("<FocusOut>", lambda e: on_focus_out(e, file_entry, "Select a CSV file"))
    file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
    widgets["entry"].append(file_entry)

    browse_button = tk.Button(file_frame, text="Browse", command=choose_csv_file,
                              bg=colors["button_bg"], fg=colors["button_fg"], relief="flat", 
                              activebackground=colors["button_active_bg"], activeforeground=colors["button_fg"])
    browse_button.pack(side=tk.RIGHT)
    widgets["button"].append(browse_button)

    # Default Message
    default_msg_label = tk.Label(right_frame, text="Default Message for CSV:", **style)
    default_msg_label.pack(anchor=tk.W, pady=(10, 2))
    widgets["label"].append(default_msg_label)
    
    default_msg_entry = tk.Entry(right_frame, width=50, relief="flat", fg=colors["secondary"], bg=colors["entry_bg"])
    default_msg_entry.insert(0, "Enter default message for CSV")
    default_msg_entry.bind("<FocusIn>", lambda e: on_focus_in(e, default_msg_entry, "Enter default message for CSV"))
    default_msg_entry.bind("<FocusOut>", lambda e: on_focus_out(e, default_msg_entry, "Enter default message for CSV"))
    default_msg_entry.pack(fill=tk.X, pady=2)
    widgets["entry"].append(default_msg_entry)

    # Default Attachments
    default_attachment_label = tk.Label(right_frame, text="Default Attachments for CSV (optional):", **style)
    default_attachment_label.pack(anchor=tk.W, pady=(10, 2))
    widgets["label"].append(default_attachment_label)
    
    default_attachment_frame = tk.Frame(right_frame, bg=colors["bg"])
    default_attachment_frame.pack(fill=tk.X, pady=2)
    widgets["frame"].append(default_attachment_frame)
    
    default_attachment_listbox = Listbox(default_attachment_frame, height=3, bg=colors["entry_bg"], fg=colors["secondary"], relief="flat")
    default_attachment_listbox.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
    widgets["listbox"].append(default_attachment_listbox)
    
    default_attachment_button = tk.Button(default_attachment_frame, text="Browse", 
                                       command=lambda: choose_attachment_files(default_attachment_listbox),
                                       bg=colors["button_bg"], fg=colors["button_fg"], relief="flat", 
                                       activebackground=colors["button_active_bg"], activeforeground=colors["button_fg"])
    default_attachment_button.pack(side=tk.RIGHT)
    widgets["button"].append(default_attachment_button)

    # Bottom Section (Progress and Buttons)
    bottom_frame = tk.Frame(root, bg=colors["bg"])
    bottom_frame.pack(fill=tk.X, pady=10, padx=15)
    widgets["frame"].append(bottom_frame)
    
    # Progress Bar
    progress_label = tk.Label(bottom_frame, text="Progress:", **style)
    progress_label.pack(anchor=tk.W)
    widgets["label"].append(progress_label)
    
    progress_style = ttk.Style()
    progress_style.theme_use('default')
    progress_style.configure("WhatsApp.Horizontal.TProgressbar", 
                           background=colors["progress_fg"],
                           troughcolor=colors["progress_bg"])
    
    progress_bar = ttk.Progressbar(bottom_frame, style="WhatsApp.Horizontal.TProgressbar", 
                                  orient="horizontal", length=970, mode="determinate")
    progress_bar.pack(fill=tk.X, pady=5)
    widgets["progress"].append(progress_bar)

    # Action Buttons
    button_frame = tk.Frame(bottom_frame, bg=colors["bg"])
    button_frame.pack(fill=tk.X, pady=10)
    widgets["frame"].append(button_frame)

    reset_button = tk.Button(button_frame, text="Reset WhatsApp Session", command=reset_session,
                           font=("Helvetica", 12), bg=colors["reset_button_bg"], fg=colors["button_fg"], 
                           relief="flat", width=20, height=1, 
                           activebackground=colors["reset_button_active_bg"], activeforeground=colors["button_fg"])
    reset_button.pack(side=tk.LEFT, padx=10)
    widgets["reset_button"].append(reset_button)

    send_button = tk.Button(button_frame, text="Send Messages", command=send_all,
                          font=("Helvetica", 14, "bold"), bg=colors["send_button_bg"], fg=colors["button_fg"], 
                          relief="flat", width=20, height=2, 
                          activebackground=colors["send_button_active_bg"], activeforeground=colors["button_fg"])
    send_button.pack(side=tk.RIGHT, padx=10)
    widgets["send_button"].append(send_button)

    # Log Section
    log_frame = tk.Frame(root, bg=colors["bg"])
    log_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=5)
    widgets["frame"].append(log_frame)
    
    log_label = tk.Label(log_frame, text="Activity Log:", **style)
    log_label.pack(anchor=tk.W)
    widgets["label"].append(log_label)
    
    log_output = scrolledtext.ScrolledText(log_frame, height=10, 
                                         state=tk.DISABLED, bg=colors["log_bg"], fg=colors["log_fg"])
    log_output.pack(fill=tk.BOTH, expand=True, pady=5)
    widgets["log"].append(log_output)

    # Footer
    footer = tk.Label(root, text="Developed by Abdul Basit", font=("Helvetica", 10), 
                    fg=colors["fg"], bg=colors["bg"])
    footer.pack(pady=5)
    widgets["label"].append(footer)

    gui_log("info", "Application started. Ready to send messages.")

    root.mainloop()