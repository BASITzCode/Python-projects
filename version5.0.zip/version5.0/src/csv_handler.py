import os
import csv
from src.whatsapp import log_message

def read_contacts_from_csv(filepath, default_message="", default_attachments=None):
    """Read contact information from a CSV file, including optional comma-separated attachments"""
    contacts = []
    default_attachments = default_attachments or []
    
    if not filepath or not isinstance(filepath, str):
        log_message("error", "Invalid file path provided")
        return contacts
        
    if not os.path.isfile(filepath):
        log_message("error", f"File does not exist at path: {filepath}")
        return contacts
        
    if not filepath.lower().endswith('.csv'):
        log_message("error", "File must be a CSV file")
        return contacts

    try:
        with open(filepath, mode='r', newline='', encoding='utf-8') as file:
            if os.fstat(file.fileno()).st_size == 0:
                log_message("error", "CSV file is empty")
                return contacts
                
            reader = csv.DictReader(file)
            
            if 'phone' not in reader.fieldnames:
                log_message("error", "CSV must contain 'phone' column")
                return contacts
                
            for row_num, row in enumerate(reader, 1):
                try:
                    phone = row.get("phone", "").strip()
                    message = row.get("message", "").strip() or default_message
                    attachment_str = row.get("attachments", "").strip()
                    
                    # Parse attachments (comma-separated)
                    attachments = [path.strip() for path in attachment_str.split(",") if path.strip()] if attachment_str else default_attachments
                    
                    if not phone:
                        log_message("warning", f"Empty phone number in row {row_num} - skipped")
                        continue
                        
                    if not phone.lstrip('+').isdigit():
                        log_message("warning", f"Invalid phone number format in row {row_num} - {phone}")
                        continue
                        
                    # Validate attachments
                    valid_attachments = []
                    for attachment in attachments:
                        if not os.path.isfile(attachment):
                            log_message("warning", f"Attachment file not found in row {row_num}: {attachment}")
                            continue
                        valid_attachments.append(attachment)
                    
                    contacts.append((phone, message, valid_attachments))
                    
                except Exception as row_error:
                    log_message("warning", f"Error processing row {row_num}: {str(row_error)}")
                    continue
                    
    except PermissionError:
        log_message("error", f"Permission denied when accessing {filepath}")
    except UnicodeDecodeError:
        log_message("error", "Could not decode file (ensure it's UTF-8 encoded)")
    except csv.Error as e:
        log_message("error", f"CSV parsing error: {str(e)}")
    except Exception as e:
        log_message("error", f"Unexpected error reading CSV: {str(e)}")
    
    if not contacts:
        log_message("warning", "No valid contacts found in CSV file")
        
    return contacts