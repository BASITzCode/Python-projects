import os

# User data directory for Chrome profile
USER_DATA_DIR = os.path.join(os.path.expanduser("~"), "WhatsAppProfile")

# Default retry count
DEFAULT_RETRIES = 1

# Wait times (seconds)
MESSAGE_SEND_WAIT = 5
PAGE_LOAD_TIMEOUT = 55
ELEMENT_WAIT_TIMEOUT = 40
QR_CODE_WAIT_TIMEOUT = 60
MESSAGE_SEND_WAIT = 5

# Supported file extensions for attachments
SUPPORTED_ATTACHMENT_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".gif", ".pdf", ".doc", ".docx", 
    ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".csv", ".mp3", 
    ".mp4", ".wav", ".avi", ".mov", ".zip"
}

# Theme colors
THEME_COLORS = {
    "light": {
        "bg": "#F0F2F5",  # Main background
        "fg": "#3B4A54",  # Primary text
        "button_bg": "#25D366",  # Primary button (WhatsApp green)
        "button_fg": "white",
        "button_active_bg": "#128C7E",  # Darker green
        "entry_bg": "white",  # Input fields
        "send_button_bg": "#25D366",  # Send button
        "send_button_active_bg": "#128C7E",
        "reset_button_bg": "#8696A0",  # Gray
        "reset_button_active_bg": "#667781",  # Darker gray
        "log_bg": "white",  # Message log
        "log_fg": "#3B4A54",  # Log text
        "progress_bg": "#E8F5E9",  # Light green background
        "progress_fg": "#25D366",  # WhatsApp green progress
        "secondary": "#8696A0"  # Placeholder
    },
    "dark": {
        "bg": "#0C1317",  # Dark background
        "fg": "#E9EDEF",  # White text
        "button_bg": "#00A884",  # Dark mode green
        "button_fg": "white",
        "button_active_bg": "#008068",  # Darker green
        "entry_bg": "#2A3942",  # Input field
        "send_button_bg": "#00A884",  # Send button
        "send_button_active_bg": "#008068",
        "reset_button_bg": "#8696A0",  # Gray button
        "reset_button_active_bg": "#667781",  # Darker gray
        "log_bg": "#202C33",  # Message log background
        "log_fg": "#E9EDEF",  # Log text
        "progress_bg": "#1F2C34",  # Dark background
        "progress_fg": "#00A884",  # Dark mode green
        "secondary": "#667781"  # Dark gray for placeholders
    }
}