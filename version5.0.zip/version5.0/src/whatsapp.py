import os
import time
import urllib.parse
import datetime
import shutil
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException, TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from src.config import USER_DATA_DIR, DEFAULT_RETRIES, MESSAGE_SEND_WAIT, PAGE_LOAD_TIMEOUT, QR_CODE_WAIT_TIMEOUT, SUPPORTED_ATTACHMENT_EXTENSIONS,ELEMENT_WAIT_TIMEOUT

def log_message(status, content, gui_log_fn=None):
    """Log messages to console and GUI (if available)"""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    message = f"[{timestamp}] {status.upper()}: {content}"
    print(message)
    if gui_log_fn:
        gui_log_fn(status, content)

def reset_whatsapp_session(gui_log_fn=None):
    """Delete saved WhatsApp session and force new QR code scan"""
    try:
        if os.path.exists(USER_DATA_DIR):
            log_message("info", f"Removing WhatsApp session from: {USER_DATA_DIR}", gui_log_fn)
            shutil.rmtree(USER_DATA_DIR)
            log_message("success", "WhatsApp session data deleted successfully", gui_log_fn)
            
        chrome_options = Options()
        chrome_options.add_argument(f"user-data-dir={USER_DATA_DIR}")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        
        try:
            driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), 
                                     options=chrome_options)
            driver.get("https://web.whatsapp.com/")
            
            log_message("info", "Waiting for QR code scan...", gui_log_fn)
            
            WebDriverWait(driver, QR_CODE_WAIT_TIMEOUT).until(
                EC.any_of(
                    EC.presence_of_element_located((By.XPATH, "//div[@data-testid='chat-list']")),
                    EC.presence_of_element_located((By.XPATH, "//div[@data-testid='chatlist-header']"))
                )
            )
            
            log_message("success", "WhatsApp Web authenticated successfully", gui_log_fn)
            driver.quit()
            return True
            
        except Exception as e:
            log_message("error", f"Error during QR scan: {str(e)}", gui_log_fn)
            if driver:
                driver.quit()
            return False
    except Exception as e:
        log_message("error", f"Failed to reset WhatsApp session: {str(e)}", gui_log_fn)
        return False

def initialize_driver():
    """Initialize and return a configured Chrome WebDriver"""
    chrome_options = Options()
    chrome_options.add_argument(f"user-data-dir={USER_DATA_DIR}")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    
    try:
        driver_path = ChromeDriverManager().install()
        driver = webdriver.Chrome(service=Service(driver_path), options=chrome_options)
        driver.set_page_load_timeout(PAGE_LOAD_TIMEOUT)
        return driver
    except Exception as e:
        log_message("error", f"Failed to initialize Chrome driver: {str(e)}")
        return None

def send_whatsapp_message(phone_number, message, attachments=None, max_retries=DEFAULT_RETRIES, gui_log_fn=None, failed_numbers=None):
    """Send a WhatsApp message to a specified phone number, with optional multiple attachments"""
    attachments = attachments or []
    for attempt in range(1, max_retries + 1):
        driver = None
        try:
            log_message("info", f"Attempt {attempt}/{max_retries} for {phone_number}", gui_log_fn)
            
            driver = initialize_driver()
            if not driver:
                log_message("error", "Failed to initialize WebDriver", gui_log_fn)
                break

            # Open WhatsApp Web with pre-filled message
            encoded_message = urllib.parse.quote(message)
            whatsapp_url = f"https://web.whatsapp.com/send?phone={phone_number}&text={encoded_message}"
            driver.get(whatsapp_url)

            # Wait for either send button or invalid number message
            element = WebDriverWait(driver, 50).until(
                EC.any_of(
                    EC.presence_of_element_located((By.XPATH, "//button[@aria-label='Send']")),
                    EC.presence_of_element_located((By.XPATH, "//div[contains(text(),'Phone number shared via url')]"))
                )
            )

            # Check for invalid number
            if element.text and "Phone number shared via url" in element.text:
                log_message("warning", f"Invalid or unregistered number: {phone_number}", gui_log_fn)
                if failed_numbers is not None:
                    failed_numbers[phone_number] = "Invalid number"
                break

            # Send attachments if provided
            attachment_success = 0
            attachment_fail = 0
            if attachments:
                for attachment_path in attachments:
                    # Validate attachment
                    if not os.path.isfile(attachment_path):
                        log_message("warning", f"Attachment file not found: {attachment_path}", gui_log_fn)
                        attachment_fail += 1
                        continue
                    
                    _, ext = os.path.splitext(attachment_path.lower())
                    if ext not in SUPPORTED_ATTACHMENT_EXTENSIONS:
                        log_message("warning", f"Unsupported attachment type for {attachment_path}: {ext}", gui_log_fn)
                        attachment_fail += 1
                        continue

                    log_message("info", f"Uploading attachment: {attachment_path}", gui_log_fn)
                    
                    # Click attachment button (paperclip icon)
                    attachment_button = WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT).until(
                        EC.element_to_be_clickable((By.XPATH, "//div[@title='Attach'] | //span[@data-icon='clip']"))
                    )
                    attachment_button.click()

                    # Select file input (images/documents)
                    file_input = WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT).until(
                        EC.presence_of_element_located((By.XPATH, "//input[@accept='*']"))
                    )
                    file_input.send_keys(os.path.abspath(attachment_path))

                    # Wait for upload to complete and send button to appear
                    send_attachment_button = WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT).until(
                        EC.element_to_be_clickable((By.XPATH, "//span[@data-icon='send']"))
                    )
                    send_attachment_button.click()

                    # Wait for attachment to be sent
                    WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT).until(
                        EC.presence_of_element_located((By.XPATH, "//span[@data-icon='msg-time'] | //span[@data-icon='msg-dblcheck']"))
                    )
                    log_message("success", f"Attachment sent to {phone_number}: {attachment_path}", gui_log_fn)
                    attachment_success += 1

                log_message("info", f"Attachment summary for {phone_number}: {attachment_success} succeeded, {attachment_fail} failed", gui_log_fn)

            # Send text message
            send_button = WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT).until(
                EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Send'] | //span[@data-icon='send']/.."))
            )
            send_button.click()

            # Wait for message to appear as sent
            WebDriverWait(driver, ELEMENT_WAIT_TIMEOUT).until(
                EC.presence_of_element_located((By.XPATH, "//span[@data-icon='msg-time'] | //span[@data-icon='msg-dblcheck']"))
            )

            log_message("success", f"Message sent to {phone_number}", gui_log_fn)
            return True

        except TimeoutException:
            log_message("error", f"Timeout while sending to {phone_number}", gui_log_fn)
        except WebDriverException as e:
            log_message("error", f"WebDriver error for {phone_number}: {e}", gui_log_fn)
        except Exception as e:
            log_message("error", f"Unexpected error for {phone_number}: {e}", gui_log_fn)
        # finally:
            # if driver:
                # driver.quit()

        if attempt < max_retries:
            log_message("retry", f"Retrying in 5 seconds...", gui_log_fn)
            time.sleep(5)
        else:
            if failed_numbers is not None:
                reason = "Retries exhausted"
                if attachments and attachment_fail == len(attachments) and attachment_success == 0:
                    reason = "All attachments failed"
                failed_numbers[phone_number] = reason

    driver.quit()
    return False